<?php
class cookie{
	// Declaración de una propiedad
	public $name;
	public $value;
	public $expire;
	public $path;
	public $domain;
	public $secure;
	public $httponly;

	
	function __construct(){}
	
	
	
	// Declaración de un método
	public function setName()/*dar name */
	{
        $this->name=$name;
    }
	public function getName()/*consultar name*/
	{
        return $this->name;
    }


    public function setValue()
    {
        $this->value=$value;
    }
    public function getValue()
    {
        return $this->value;
    }


    public function setExpire()
    {
        $this->expire=$expire;
    }
    public function getExpire()
    {
        return $this->expire;
    }


    public function setPath()
    {
        $this->path=$path;
    }
    public function getPath()
    {
        return $this->path;
    }


    public function setDomain()
    {
        $this->domain=$domain;
    }
    public function getDomain()
    {
        return $this->domain;
    }


    public function setSecure()
    {
        $this->secure=$secure;
    }
    public function getSecure()
    {
        return $this->secure;
    }


    public function setHttponly()
    {
        $this->httponly=$httponly;
    }
    public function getHttponly()
    {
        return $this->httponly;
    }

}

?>