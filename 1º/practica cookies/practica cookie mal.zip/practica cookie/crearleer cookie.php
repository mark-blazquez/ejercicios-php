<!DOCTYPE html>
<html>
<head>
	<title>ejer</title>
</head>
<body>
<?php

	/*dar valores a la cookie*/
	include "clasecookie.php";
	$cookie1 = new cookie();
	$cookie1->setName("cookie1");
	$cookie1->setValue("esto es la descripcion de la cookie");
	/*$cookie->setExpire(3600);*/

	setcookie($cookie1); 


	/*obtener cookie*/

	/*metodo orientado a objetos*/
	/*
	require_once('clasecookie.php');
	$cookie->getName("cookie1");
	echo "$cookie";

	*/


	/*metodo normal*/
	if (isset($_COOKIE[/*este es el nombre de la cookie concreta*/"cookie1"]))
	{
		echo ($_COOKIE["cookie1"]);
	}
	else
	{
		echo "la cookie no esxiste";
	}
  
?>


</body>
</html>