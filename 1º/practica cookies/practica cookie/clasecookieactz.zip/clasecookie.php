<?php
class cookie{
	// Declaración de una propiedad
	public $name="ola";
	public $value="info";
	public $expire="0";
	public $path;
	public $domain;
	public $secure;
	public $httponly;

	
	function __construct(){}
	
	
	
	// Declaración de un método
	public function setName()/*cambiar name */
	{
        $this->name;#si lo dejo asi es capaz de mostrarme lo k hay en el array
        #metodo anterior
        #$this->name=$name si lo escribo asi me sale un error de que la variable no esxiste

    }
	public function getName()/*consultar name*/
	{
        return $this->name;
    }


    public function setValue()
    {
        $this->value=$value;
    }
    public function getValue()
    {
        return $this->value;
    }


    public function setExpire()
    {
        $this->expire=$expire;
    }
    public function getExpire()
    {
        return $this->expire;
    }

	/*
    public function setPath()
    {
        $this->path=$path;
    }
    public function getPath()
    {
        return $this->path;
    }


    public function setDomain()
    {
        $this->domain=$domain;
    }
    public function getDomain()
    {
        return $this->domain;
    }


    public function setSecure()
    {
        $this->secure=$secure;
    }
    public function getSecure()
    {
        return $this->secure;
    }


    public function setHttponly()
    {
        $this->httponly=$httponly;
    }
    public function getHttponly()
    {
        return $this->httponly;
    }*/

}

?>