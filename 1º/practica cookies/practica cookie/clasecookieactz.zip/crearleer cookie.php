<!DOCTYPE html>
<html>
<head>
	<title>ejer</title>
</head>
<body>
<?php
	#importo la clase con su metodo y atributos
	include "clasecookie.php";
	#creo nuevo objeto llamado cookieuno que pertenece a clase cookie y viene con los atributos de su clase
	$cookieuno = new cookie();
	#cambiar valores de sus atributos a la cookie
	$cookieuno->setName('cookieuno');#no me cambia el nombre me sigue dejando el ola definido en la clase
	#$this->name = $name; si utilizo esto me dice k no es un objeto
	#los otros atributos
	/*$cookieuno->setValue("esto es la descripcion de la cookie");
	$cookieuno->setExpire(3600);
	 
	#el metodo que me pasaste que tampoco me consigue cambiar los valores 
	$cookieuno = new cookie("contador", "esta creada ", 300);

	#crear la cookie con las propiedades del objeto cookieuno
	/*setcookie($cookieuno);*/

#lo que yo entiendo basicamente es k tenemos un objeto con unas propiedades x ,"o sea el array" ,y kiero cambiarselos con los metodoos definidos ,y no entiendo xk no me los cambia de ningun modo porque el cambio lo realizo despues de que me llegue el objeto , y lo muestro con el print_r despues de cambiarlo ,pero me sigue dando el ola definido en la clase 

	if (isset($cookieuno)) {
		print_r($cookieuno) ;
	}
	else{
		echo "error";
	}




	#comprobar si la cookie existe

	#metodo normal
	/*if (isset($_COOKIE["cookieuno"]))
	{
		echo ($_COOKIE["cookieuno"]);
	}
	else
	{
		echo "la cookie no existe";
	}*/

	#metodo objetos--boceto
	/*$cookieuno->getName();
	return $this->name;
	print_r ($cookieuno);
	*/
  
?>


</body>
</html>