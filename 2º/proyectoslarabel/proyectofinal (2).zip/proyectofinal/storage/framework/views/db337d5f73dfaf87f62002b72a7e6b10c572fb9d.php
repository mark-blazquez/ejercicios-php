<header>
	<nav class="navbar navbar-expand-lg navbar-light bg-success">
		<div class="container-fluid">
			<a href="<?php echo e(route('pantallainicial')); ?>"><img style="" src="https://www.faxvirtual.com/blog//wp-content/uploads/2016/03/empresa-ecologica-1.jpg" class="navbar-brand rounded-circle"></img></a>
			<div class="d-flex">
				<h1 class="jsutify-content-center">PROYECTO INICIA</h1>			
			</div>
			<p>solicitar un producto</p>			
		</div>
	</nav>
</header><?php /**PATH /home/vagrant/proyectoslarabel/proyectofinal/resources/views/componentes/cabecerausuario.blade.php ENDPATH**/ ?>