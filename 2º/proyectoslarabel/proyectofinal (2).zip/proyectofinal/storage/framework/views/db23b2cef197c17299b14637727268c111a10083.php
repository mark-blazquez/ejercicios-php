
<footer class="footer fixed-bottom d-flex justify-content-center bg-dark">
	<div class="container d-flex justify-content-center ">
	  <h5 class="text-muted">hecho por mark.</h5>
	</div>
</footer><?php /**PATH /home/vagrant/proyectoslarabel/proyectofinal/resources/views/componentes/footer.blade.php ENDPATH**/ ?>